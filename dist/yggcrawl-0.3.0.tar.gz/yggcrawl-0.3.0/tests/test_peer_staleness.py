from peer_sync import is_peer_snapshot_stale, sync_from_peers


def test_peer_snapshot_rejected_if_older():
    local = {"timestamp": 200}
    peer = {"timestamp": 100}
    assert is_peer_snapshot_stale(local, peer) is True


def test_peer_snapshot_accepted_if_newer():
    local = {"timestamp": 100}
    peer = {"timestamp": 200}
    assert is_peer_snapshot_stale(local, peer) is False


def test_peer_snapshot_accepted_if_equal():
    local = {"timestamp": 100}
    peer = {"timestamp": 100}
    assert is_peer_snapshot_stale(local, peer) is False


def test_peer_snapshot_accepted_if_missing_timestamp():
    local = {"timestamp": 100}
    peer = {}
    assert is_peer_snapshot_stale(local, peer) is False


def test_stale_peer_not_merged(monkeypatch):
    # Mocking a stale peer and a fresh peer
    peer_responses = [
        ({"timestamp": 100, "records": []}, None),  # Stale
        ({"timestamp": 300, "records": []}, None),  # Fresh
    ]
    
    # Simple iterator to return different peer data
    it = iter(peer_responses)
    monkeypatch.setattr("peer_sync.fetch_verified_snapshot", lambda url: next(it))
    monkeypatch.setattr("peer_sync.validate_snapshot", lambda snapshot: True)

    calls = {"merged": 0}

    class DummyIndexer:
        def load_snapshot(self):
            return {"timestamp": 200, "records": []}

        def merge_peer_snapshot(self, snapshot):
            calls["merged"] += 1
            return {"added": 0, "updated": 0, "ignored": 0}

    totals = sync_from_peers(DummyIndexer(), ["peer_stale", "peer_fresh"])

    # Should only merge the fresh one
    assert calls["merged"] == 1
    assert totals["peers_total"] == 2
    assert totals["peers_ok"] == 1
    assert totals["ignored"] == 1