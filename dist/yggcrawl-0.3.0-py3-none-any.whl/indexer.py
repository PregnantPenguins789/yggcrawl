import json
import hashlib
import time
import os
import shutil
from datetime import datetime
from typing import Optional

import config
from logger import logger
from validator import validate_snapshot, validate_diff


class Indexer:
    def __init__(self):
        self.records = []
        self.index = {}  # Added to support fast lookups and state reporting

    def verify_snapshot_files(self):
        """Checks if the snapshot and its hash file exist and match."""
        if not os.path.exists(config.SNAPSHOT_FILE):
            return False, "snapshot file missing"

        if not os.path.exists(config.SNAPSHOT_HASH_FILE):
            return False, "snapshot hash file missing"

        with open(config.SNAPSHOT_FILE, "rb") as f:
            snapshot_bytes = f.read()

        with open(config.SNAPSHOT_HASH_FILE, "r", encoding="utf-8") as f:
            stored_hash = f.read().strip()

        computed_hash = hashlib.sha256(snapshot_bytes).hexdigest()

        if stored_hash != computed_hash:
            return False, "snapshot hash mismatch"

        return True, None

    def add_record(self, url: str, content):
        """Hashes content and adds or updates a record in the current run."""
        if isinstance(content, str):
            content_bytes = content.encode("utf-8")
        else:
            content_bytes = content

        content_hash = hashlib.sha256(content_bytes).hexdigest()
        fetched_at = int(datetime.now().timestamp())

        # Update both the list (for saving) and the dict (for reporting/lookups)
        self.index[url] = {
            "content_hash": content_hash,
            "fetched_at": fetched_at
        }

        for record in self.records:
            if record["url"] == url:
                record["content_hash"] = content_hash
                record["fetched_at"] = fetched_at
                return

        self.records.append({
            "url": url,
            "content_hash": content_hash,
            "fetched_at": fetched_at,
        })

    def save_snapshot(self):
        """Serializes current records to a deterministic JSON snapshot."""
        snapshot = {
            "node_id": config.NODE_ID,
            "schema_version": config.SCHEMA_VERSION,
            "timestamp": int(datetime.now().timestamp()),
            "records": sorted(self.records, key=lambda x: x["url"]),
        }

        data = json.dumps(snapshot, indent=2, sort_keys=True)

        with open(config.SNAPSHOT_FILE, "w", encoding="utf-8") as f:
            f.write(data)

        snapshot_hash = hashlib.sha256(data.encode("utf-8")).hexdigest()
        with open(config.SNAPSHOT_HASH_FILE, "w", encoding="utf-8") as f:
            f.write(snapshot_hash)

        archive_dir = os.path.join(config.SNAPSHOTS_DIR, "archive")
        os.makedirs(archive_dir, exist_ok=True)

        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        archive_path = os.path.join(archive_dir, f"snapshot_{timestamp_str}.json")
        shutil.copy(config.SNAPSHOT_FILE, archive_path)

        logger.info(f"Snapshot saved with {len(self.records)} records")
        return snapshot_hash

    def load_snapshot(self) -> Optional[dict]:
        """Loads and verifies the existing local snapshot."""
        is_valid, error = self.verify_snapshot_files()
        if not is_valid:
            logger.warning(f"Previous snapshot unavailable: {error}")
            return None

        with open(config.SNAPSHOT_FILE, "r", encoding="utf-8") as f:
            snapshot = json.load(f)

        if not validate_snapshot(snapshot):
            return None

        records = snapshot.get("records", [])
        self.records = records  # Restore the list for future saves
        self.index = {
            record["url"]: {
                "fetched_at": record["fetched_at"],
                "content_hash": record["content_hash"],
            }
            for record in records
        }

        logger.info(f"Loaded snapshot: {len(records)} records")
        return snapshot

    def diff_against(self, old_snapshot: dict) -> dict:
        """Compares current records against an old snapshot to find changes."""
        old_map = {r["url"]: r["content_hash"] for r in old_snapshot.get("records", [])}
        diff = {"new": [], "changed": [], "unchanged": []}

        for record in sorted(self.records, key=lambda x: x["url"]):
            url = record["url"]
            if url not in old_map:
                diff["new"].append(url)
            elif old_map[url] != record["content_hash"]:
                diff["changed"].append(url)
            else:
                diff["unchanged"].append(url)

        return diff if validate_diff(diff) else {"new": [], "changed": [], "unchanged": []}

    def merge_peer_snapshot(self, peer_data: dict) -> dict:
        stats = {"added": 0, "updated": 0, "ignored": 0}
        local_map = {record["url"]: record for record in self.records}

        for peer_record in peer_data.get("records", []):
            url = peer_record["url"]
            peer_fetched_at = peer_record["fetched_at"]
            peer_content_hash = peer_record["content_hash"]

            if url not in local_map:
                new_record = {
                    "url": url,
                    "content_hash": peer_content_hash,
                    "fetched_at": peer_fetched_at,
                }
                self.records.append(new_record)
                local_map[url] = new_record
                self.index[url] = {"content_hash": peer_content_hash, "fetched_at": peer_fetched_at}
                stats["added"] += 1
                continue

            local_record = local_map[url]
            if peer_fetched_at > local_record["fetched_at"]:
                local_record["content_hash"] = peer_content_hash
                local_record["fetched_at"] = peer_fetched_at
                self.index[url] = {"content_hash": peer_content_hash, "fetched_at": peer_fetched_at}
                stats["updated"] += 1
            else:
                stats["ignored"] += 1

        logger.info(
            f"Merged peer snapshot: "
            f"{stats['added']} added, "
            f"{stats['updated']} updated, "
            f"{stats['ignored']} ignored"
        )
        return stats